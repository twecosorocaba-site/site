(function patch(){
 const fs=require('fs'),path=require('path');
 const root=process.env.TWCO_PUBLIC_DIR || '/vercel/twco_preview';
 const p=x=>path.join(root,x);
 let html=fs.readFileSync(p('index.html'),'utf8');
 // The approved four services are retained directly after the hero.
 const attentionEnd=html.indexOf('<section class="reviews" id="avaliacoes">');
 if(attentionEnd<0||!html.includes('id="servicos"'))throw Error('Unexpected V17 structure');
 const diagnose=`<section class="diagnostic" id="explique-seu-problema"><div class="container">
 <div class="diagnostic-shell">
  <div class="diagnostic-intro"><span class="diag-flare" aria-hidden="true">✧</span><span class="eyebrow">Orientação inicial</span><h2>Explique o seu <span class="serif green">problema.</span></h2><p>Descreva o que está acontecendo com seu veículo e receba uma orientação preliminar. Nossa equipe pode ajudar a confirmar o próximo passo.</p>
   <div class="diag-benefits"><span><i aria-hidden="true">⌁</i> Análise inicial</span><span><i aria-hidden="true">◇</i> Resposta clara</span><span><i aria-hidden="true">♙</i> Atendimento humano</span></div>
  </div>
  <div class="diagnostic-console">
   <div class="diag-status"><span class="diag-pulse"></span> Atendimento TW&CO <span class="diag-status-right">Orientação preliminar</span></div>
   <form id="diagnosticForm" class="diag-form"><label class="sr-only" for="diagnosticText">Explique o seu problema</label><textarea id="diagnosticText" rows="3" minlength="8" maxlength="900" required placeholder="Ex.: Meu carro faz um barulho na frente quando passo em lombadas. O que pode ser?"></textarea><button type="submit" aria-label="Receber orientação inicial"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="m4 12 16-8-6 16-2.8-7.2L4 12Zm7.2.8L20 4"/></svg></button></form>
   <div class="diag-response" id="diagnosticAnswer" aria-live="polite"><div class="diag-response-mark"><img src="assets/logo-twco.svg" alt="TW&CO" loading="lazy"/></div><div class="diag-response-body"><small id="diagnosticLabel">Exemplo de orientação</small><p id="diagnosticReply">Ruídos ao passar por irregularidades podem estar associados a componentes da suspensão, mas a origem só pode ser confirmada após uma avaliação presencial do veículo.</p><a id="diagnosticWhatsApp" class="diag-consult" href="https://wa.me/5515996638821?text=Ol%C3%A1%2C%20gostaria%20de%20falar%20com%20um%20atendente." target="_blank" rel="noopener noreferrer"><svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M20 11.5a8 8 0 0 1-12 7L3 20l1.5-5a8 8 0 1 1 15.5-3.5Z"/><path d="M8 10.5c1.5 3 3 4.5 6 5"/></svg> Resolver com um atendente <span>↗</span></a></div></div>
   <p class="diag-note">A orientação não substitui um diagnóstico mecânico presencial.</p>
  </div>
 </div></div></section>`;
 const review=`<section class="reviews" id="avaliacoes"><div class="container review-section-grid">
 <div class="review-sidebar"><span class="eyebrow">Confiança</span><h2>O que nossos<br/>clientes <span class="serif">dizem.</span></h2>
 <div class="review-google"><div aria-label="Google" class="google-word"><span style="color:#4285F4">G</span><span style="color:#EA4335">o</span><span style="color:#FBBC05">o</span><span style="color:#4285F4">g</span><span style="color:#34A853">l</span><span style="color:#EA4335">e</span></div>
 <div class="review-score">5,0 <span class="stars">★★★★★</span></div><small>4 avaliações verificadas no Google Maps em 29/10/2026</small></div>
 <a class="review-google-link" href="https://maps.app.goo.gl/KH8BSwpBCeTkNb8z7" target="_blank" rel="noopener noreferrer">Ver avaliações no Google ↗</a>
 </div>
 <div class="review-slider"><div class="reviews-viewport" id="reviewViewport" tabindex="0" aria-label="Avaliações reais, carrossel automático"><div class="reviews-track" id="reviewTrack"></div></div>
 <div class="review-progress"><span aria-hidden="true"></span></div><div class="review-caption" id="reviewCount">4 avaliações de 5 estrelas · Google Maps</div></div>
 <p class="reviews-note" id="reviewNote">Avaliações consultadas no Google Maps em 29/10/2026. Novos comentários dependem de integração autorizada.</p>
 </div></section>`;
 const revIndex=html.indexOf('<section class="reviews" id="avaliacoes">');
 const ctaIndex=html.indexOf('<section aria-label="Entre em contato" class="cta">');
 const locationIndex=html.indexOf('<section class="location" id="contato">');
 if(ctaIndex<revIndex||locationIndex<ctaIndex)throw Error('Sections moved unexpectedly');
 // New composition follows the latest approved mockup: hero / services / attention / form / testimonials / contact.
 html=html.slice(0,revIndex)+diagnose+review+html.slice(locationIndex);
 const liveChatStart=html.indexOf('<button aria-controls="chatPanel"');
 const scriptAt=html.indexOf('<script defer="" src="assets/site.js"></script>');
 if(liveChatStart>=0 && scriptAt>liveChatStart)html=html.slice(0,liveChatStart)+html.slice(scriptAt);
 // Premium vector line icons, rather than placeholder glyphs.
 const icons=[
 `<svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M20.5 11.7a8.7 8.7 0 0 1-12.8 7.6L3 20.7l1.4-4.5A8.7 8.7 0 1 1 20.5 11.7Z"/><path d="M8 9.2c.8 3 3.5 5.5 6.7 6.3l1.5-1.6-2.5-1.2-.9 1c-1.4-.6-2.6-1.7-3.2-3l.9-.9-1.3-2.4L8 9.2Z"/></svg>`,
 `<svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M6 3.8 9 3l2.2 4.5-2 2.1c1.2 2.3 3 4.1 5.4 5.4l2.1-2 4.4 2.1-.8 3.1c-.3 1-1.2 1.8-2.3 1.8C10.5 20 4 13.5 4 6.1c0-1 .8-2 2-2.2Z"/></svg>`,
 `<svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M19.5 10c0 5.3-7.5 11-7.5 11S4.5 15.3 4.5 10a7.5 7.5 0 1 1 15 0Z"/><circle cx="12" cy="10" r="2.4"/></svg>`];
 ['◉','◖','⌖'].forEach((icon,i)=>{const before=`<span aria-hidden="true" class="contact-icon">${icon}</span>`;if(!html.includes(before))throw Error('Missing contact icon '+icon);html=html.replace(before,`<span class="contact-icon">${icons[i]}</span>`)});
 html=html.replace('<title>TW&amp;CO Premium | Oficina Especializada em Sorocaba — V17</title>','<title>TW&amp;CO Premium | Oficina Especializada em Sorocaba</title>');
 html=html.replace('<script defer="" src="assets/site.js"></script>','<script defer src="assets/site.js"></script><script defer src="assets/experience.js"></script>');
 fs.writeFileSync(p('index.html'),html,'utf8');
 const css=`
/* TW&CO PREMIUM — approved editorial composition (V18). Underlying photos and emblem remain intact. */
:root {--green:#00e477;--bg:#031610;--ink:#f2f7f3;--muted:#aec9ba;}
body{background:#031610;}
.hero{height:clamp(660px,100svh,870px);min-height:660px;}
.hero-scene,.roof-front{left:auto!important;right:0!important;width:auto!important;min-width:0!important;max-width:none!important;height:100%!important;object-fit:contain!important;object-position:right bottom!important;}
.hero-curtain{background:linear-gradient(90deg,#02150ffb 0%,#02150ff7 20%,#02150ff0 30%,#02150fc9 40%,#02150f73 47%,transparent 59%),linear-gradient(0deg,#02150f0a,transparent 24%);}
.hero-header-bg{background:linear-gradient(90deg,#041810f5,#042016e8 65%,#052518e8);height:104px;}
.hero h1{font-size:clamp(47px,4.3vw,69px);font-weight:400;letter-spacing:-.055em;line-height:1.055;margin:22px 0 30px;}
.hero h1 .serif{font-size:1.12em;letter-spacing:-.012em;}
.hero-copy-inner{max-width:min(670px,56%);}
.hero-copy{align-items:center;}
.hero-description{font-size:14px;line-height:1.8;max-width:460px;}
.hero-detail{margin-top:20px;}
.hero-progress{display:none;}
/* Four modest cards directly beneath the hero */
.services{padding:95px 0 116px;background:linear-gradient(180deg,#02150f 0%,#031c14 100%);}
.services-grid{grid-template-columns:repeat(4,minmax(0,1fr));gap:16px;}
.section-top{margin-bottom:40px;}
.service-card{height:clamp(285px,23vw,340px);box-shadow:none;}
.service-details{padding:22px 21px 24px;}
.service-details h3{font-size:17px;}
.service-details p{font-size:11px;}
/* Reception reference — same approved original photo */
.attention{padding:78px 0 67px;background:linear-gradient(180deg,#031c14,#031911);}
.attention-panel{grid-template-columns:1.04fr .96fr;gap:clamp(38px,5.3vw,85px);min-height:390px;}
.attention-image{min-height:390px;}
.attention-copy h2{font-size:clamp(38px,3.4vw,54px);font-weight:400;}
.attention-copy .serif{font-size:1.1em;}
.feature-mark{font-family:Georgia,serif;}
/* Single in-page vehicle concern form, replaces floating chat */
.chat-launch,.chat-panel{display:none!important;}
.diagnostic{position:relative;background:radial-gradient(ellipse at 17% 68%,rgba(0,229,119,.075),transparent 46%),#031911;padding:45px 0 135px;overflow:hidden;isolation:isolate;}
.diagnostic:before{content:"";position:absolute;left:-15%;right:-15%;bottom:0;height:58%;background:radial-gradient(ellipse at center,rgba(0,203,105,.055),transparent 60%);z-index:-1;pointer-events:none;}
.diagnostic-shell{display:grid;grid-template-columns:.85fr 1.15fr;gap:clamp(26px,4.5vw,82px);align-items:center;border:1px solid rgba(0,228,119,.48);border-radius:25px;padding:clamp(30px,4vw,64px);background:linear-gradient(125deg,rgba(8,62,41,.79),rgba(5,35,25,.93) 42%,rgba(7,56,37,.67));box-shadow:inset 0 1px 0 rgba(196,255,218,.10),0 28px 90px rgba(0,0,0,.16);backdrop-filter:blur(15px);}
.diag-flare{display:block;font-size:26px;color:var(--green);line-height:1;margin-bottom:18px;}
.diagnostic-intro .eyebrow{font-size:10px;letter-spacing:.19em;}
.diagnostic-intro h2{font-size:clamp(38px,3.6vw,57px);font-weight:400;line-height:1.05;letter-spacing:-.055em;margin:20px 0 20px;}
.diagnostic-intro .serif{display:inline-block;font-size:1.16em;}
.diagnostic-intro>p{max-width:365px;font-size:14px;line-height:1.85;color:#bed8c9;}
.diag-benefits{display:flex;flex-wrap:wrap;gap:14px;margin-top:39px;}
.diag-benefits span{display:flex;gap:10px;align-items:center;font-size:11px;line-height:1.45;color:#cde7d5;}
.diag-benefits i{font-style:normal;display:grid;place-items:center;color:#00e477;border:1px solid rgba(0,228,119,.7);width:37px;height:37px;border-radius:50%;font-size:21px;flex-shrink:0;}
.diagnostic-console{background:linear-gradient(145deg,rgba(4,30,22,.92),rgba(4,48,31,.86));border:1px solid rgba(198,255,221,.14);border-radius:17px;padding:23px;box-shadow:0 25px 80px rgba(0,0,0,.16);}
.diag-status{display:flex;align-items:center;gap:8px;font-size:11px;color:#d2ebda;margin-bottom:15px;font-weight:500;}
.diag-pulse{height:7px;width:7px;border-radius:50%;background:var(--green);box-shadow:0 0 10px #00e47799;}
.diag-status-right{margin-left:auto;color:#88b69c;font-size:10px;font-weight:400;}
.diag-form{position:relative;display:flex;align-items:stretch;gap:10px;}
.diag-form textarea{width:100%;resize:vertical;min-height:91px;max-height:250px;border:1px solid #99d8ad70;border-radius:13px;background:rgba(1,19,13,.64);color:#f6fff6;padding:18px 67px 18px 17px;font-size:13px;line-height:1.6;outline:0;}
.diag-form textarea::placeholder{color:#a8beae;opacity:.95;}
.diag-form textarea:focus{border-color:var(--green);box-shadow:0 0 0 3px #00e47719;}
.diag-form button{position:absolute;right:9px;top:10px;width:46px;height:46px;border:0;border-radius:10px;background:var(--green);color:#032015;display:grid;place-items:center;transition:transform .2s;}
.diag-form button:hover{transform:translateY(-2px);}
.diag-form button svg{width:21px;height:21px;}
.diag-response{display:flex;align-items:flex-start;gap:11px;margin-top:15px;}
.diag-response-mark{width:42px;height:42px;border-radius:50%;border:1px solid #a1e8bf50;background:#03120e;flex:0 0 auto;display:grid;place-items:center;padding:7px;}
.diag-response-mark img{max-width:100%;max-height:100%;}
.diag-response-body{flex:1;min-width:0;border:1px solid #c5f2d137;border-radius:12px;padding:16px 19px;background:rgba(2,28,19,.48);}
.diag-response-body small{display:block;color:var(--green);font-size:9px;text-transform:uppercase;letter-spacing:.15em;margin-bottom:6px;}
.diag-response-body p{color:#e5f4e9;font-size:12px;line-height:1.8;margin-bottom:16px;}
.diag-consult{display:inline-flex;align-items:center;gap:10px;color:var(--green);font-weight:550;font-size:11px;border:1px solid var(--green);border-radius:8px;padding:11px 13px;}
.diag-consult:hover{background:rgba(0,228,119,.08);}
.diag-consult svg{height:16px;width:16px;}.diag-consult span{margin-left:7px;font-size:15px;}
.diag-note{font-size:10px;margin:12px 0 0 52px;color:#91b09d;}
.sr-only{position:absolute!important;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0;}
/* Auto-scrolling Google carousel; no next/back/pause controls */
.reviews{padding:102px 0 126px;background:#031710;}
.review-section-grid{display:grid;grid-template-columns:330px minmax(0,1fr);column-gap:clamp(35px,4.1vw,75px);align-items:center;}
.review-sidebar h2{font-size:clamp(40px,3.5vw,55px);font-weight:400;line-height:1.15;letter-spacing:-.05em;margin:24px 0 50px;}
.review-google .google-word{font-size:34px;}
.review-score{margin:20px 0 3px;font-size:25px;}
.review-google small{display:block;max-width:245px;font-size:11px;line-height:1.65;color:#98b5a5;}
.review-google-link{display:inline-block;margin-top:25px;font-size:11px;color:#9bceb1;border-bottom:1px solid #44765b;padding-bottom:5px;}
.review-google-link:hover{color:var(--green);}
.review-slider{width:100%;overflow:hidden;align-self:center;}
.review-card{flex-basis:clamp(340px,39vw,550px);min-height:290px;padding:29px 32px;border-radius:15px;background:linear-gradient(140deg,#0a2419,#071a14);border-color:#247c4b6b;}
.review-card blockquote{font-size:clamp(23px,2.2vw,31px);margin:27px 0;line-height:1.28;}
.review-top::after{content:"G";margin-left:auto;font:bold 28px Arial,sans-serif;color:#4285f4;}
.review-progress{height:3px;background:rgba(255,255,255,.1);margin-top:26px;position:relative;overflow:hidden;}
.review-progress span{display:block;height:100%;width:18%;background:linear-gradient(90deg,#007c45,var(--green));animation:review-progress 17.2s linear infinite;}
@keyframes review-progress{from{transform:translateX(-100%)}to{transform:translateX(580%)}}
.review-caption{margin-top:19px;color:#9ab7a4;font-size:10px;}
.reviews-note{grid-column:1/-1;margin-top:25px;color:#89a798;font-size:10px;}
.review-buttons,.review-controls{display:none!important;}
/* Contact row with precise custom SVG line icons */
.location{padding:105px 0 88px;background:linear-gradient(180deg,#031b13,#03130e);}
.contact-heading{grid-template-columns:.9fr 1.3fr;gap:50px;}
.contact-heading h2{font-size:clamp(40px,3.5vw,55px);}
.contact-cards{gap:15px;}
.contact-card{position:relative;min-height:205px;border:1px solid rgba(0,228,119,.21);border-radius:15px;flex-direction:column;align-items:flex-start;justify-content:center;padding:25px;background:linear-gradient(130deg,#08291b,#041b13);}
.contact-card:hover{border-color:var(--green);}
.contact-icon{display:grid;place-items:center;min-width:54px;width:54px;height:54px;border-radius:50%;border:1px solid rgba(0,228,119,.48);background:#093321;color:var(--green);}
.contact-icon svg{width:24px;height:24px;stroke:currentColor;display:block;}
.contact-arrow{position:absolute;top:17px;right:18px;font-size:16px;}
.contact-card-text small{font-size:12px;}
.contact-card-text strong{font-size:13px;}
.footer{background:#02120c;}
@media(max-width:1180px){
 .services-grid{grid-template-columns:repeat(2,minmax(0,1fr));}
 .review-section-grid{grid-template-columns:250px minmax(0,1fr);}
 .contact-heading{grid-template-columns:1fr;gap:30px;}
}
@media(max-width:860px){
 .hero-scene,.roof-front{width:100%!important;height:100%!important;object-fit:cover!important;object-position:center center!important;}
 .hero{height:auto;min-height:0;}
 .services{padding:70px 0 89px;}
 .attention{padding:45px 0 60px;}
 .diagnostic{padding:28px 0 93px;}
 .diagnostic-shell{grid-template-columns:1fr;padding:26px;}
 .diag-benefits{margin-top:25px;}
 .reviews{padding:88px 0 90px;}
 .review-section-grid{grid-template-columns:1fr;gap:28px;}
 .review-sidebar h2{margin:19px 0 24px;}
 .review-google{display:flex;flex-wrap:wrap;align-items:center;gap:6px 20px;}
 .review-google small{flex-basis:100%;}
 .review-score{margin:0;}
 .review-google-link{margin-top:15px;}
 .reviews-note{margin-top:0;}
 .location{padding:83px 0 70px;}
}
@media(max-width:600px){
 .services-grid{grid-template-columns:1fr;gap:14px;}
 .service-card{height:325px;}
 .diagnostic-shell{padding:21px;border-radius:17px;gap:27px;}
 .diagnostic-intro h2{font-size:39px;}
 .diagnostic-console{padding:13px;}
 .diag-benefits{gap:12px;}
 .diag-benefits span{font-size:10px;}
 .diag-benefits i{width:30px;height:30px;}
 .diag-response-mark{width:32px;height:32px;padding:5px;}
 .diag-response-body{padding:13px;}
 .diag-note{margin-left:0;}
 .diag-consult{font-size:10px;padding:10px;}
 .review-card{flex-basis:88%;padding:24px;min-height:250px;}
 .review-card blockquote{font-size:23px;}
 .contact-cards{grid-template-columns:1fr;}
 .contact-card{min-height:116px;flex-direction:row;align-items:center;padding:19px;}
 .contact-icon{width:47px;height:47px;min-width:47px;}
 .contact-heading h2{font-size:42px;}
}
@media(prefers-reduced-motion:reduce){.review-progress span{animation:none;transform:none;width:25%;}}
`;
 fs.appendFileSync(p('assets/site.css'),css,'utf8');
 const script=`
(()=>{'use strict';
 const form=document.getElementById('diagnosticForm');
 const text=document.getElementById('diagnosticText');
 const response=document.getElementById('diagnosticReply');
 const label=document.getElementById('diagnosticLabel');
 const link=document.getElementById('diagnosticWhatsApp');
 if(!form||!text||!response||!link)return;
 const guidance=[
  {re:/freio|pedal|pastilha|disco|abs|frenagem/i,msg:'Questões relacionadas à frenagem exigem atenção. Ruídos, vibrações ou alterações no pedal podem ter diferentes causas. Evite continuar dirigindo se os freios estiverem comprometidos; a equipe precisa avaliar o veículo presencialmente.'},
  {re:/suspens|amortec|lombada|buraco|barulho|estal|batid|pneu|roda|direç|volante/i,msg:'Ruídos ou vibrações nessa situação podem estar relacionados a pneus, direção ou componentes da suspensão. A origem depende de uma inspeção presencial; podemos ajudar a agendar uma avaliação com a equipe.'},
  {re:/câmbio|cambio|marcha|embreagem|transmiss|tranco/i,msg:'Trancos ou dificuldades nas trocas de marcha podem estar associados a diferentes componentes da transmissão e aos fluidos. A avaliação técnica é importante para identificar a causa antes de indicar qualquer serviço.'},
  {re:/motor|óleo|oleo|falha|potência|potencia|injeção|injeção|luz|painel|acende|vazament/i,msg:'Esse sintoma pode ter várias origens mecânicas ou eletrônicas. Se houver superaquecimento, pressão de óleo baixa ou falha grave, pare em local seguro. Uma avaliação técnica pode identificar a causa e o procedimento correto.'},
  {re:/água|agua|temperatura|radiador|esquent|arrefec|superaquec/i,msg:'Alterações de temperatura ou no arrefecimento precisam de atenção imediata. Se o motor estiver superaquecendo, pare em local seguro e evite abrir o reservatório quente. Um profissional deve avaliar o veículo.'}
 ];
 form.addEventListener('submit',event=>{
   event.preventDefault();
   const question=text.value.trim();
   if(question.length<8){text.setCustomValidity('Descreva o problema com mais detalhes.');text.reportValidity();return;}
   text.setCustomValidity('');
   const item=guidance.find(x=>x.re.test(question));
   response.textContent=item?item.msg:'Obrigado por explicar. O sintoma pode ter várias causas; sem examinar o veículo não é possível identificar o problema com segurança. Nossa equipe pode orientar o próximo passo e agendar uma avaliação presencial.';
   label.textContent='Orientação inicial da TW&CO';
   const wa='Olá! Descrevi um problema no site da TW&CO: '+question+'\\n\\nGostaria de conversar com um atendente e agendar uma avaliação.';
   link.href='https://wa.me/5515996638821?text='+encodeURIComponent(wa);
   document.getElementById('diagnosticAnswer')?.scrollIntoView({block:'nearest',behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});
 });
 text.addEventListener('input',()=>text.setCustomValidity(''));
})();
`;
 fs.writeFileSync(p('assets/experience.js'),script,'utf8');
 // deployment validation ensures no inline generated-image replacements.
 for(const f of ['assets/hero-referencia-exata.png','assets/logo-twco.svg','assets/servico-cambio.webp','assets/servico-freios.webp'])if(!fs.existsSync(p(f)))throw Error('Missing approved asset '+f);
 console.log('TWCO V18 PATCH OK',html.length,css.length,script.length);
})();
