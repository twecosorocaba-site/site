/**
 * TW&CO Premium — Google Business Profile Reviews (Vercel serverless)
 * Requires authorized, verified business profile and Google API access.
 * No sample reviews are returned: without credentials, frontend shows a transparent fallback.
 */
const snapshot = require("../assets/avaliacoes-verificadas.json");
let cache = { expires: 0, payload: null };
const REQUIRED = ["GBP_CLIENT_ID", "GBP_CLIENT_SECRET", "GBP_REFRESH_TOKEN", "GBP_ACCOUNT_ID", "GBP_LOCATION_ID"];
function fail(res, code, status) { return res.status(code).json({ status, reviews: [] }); }
async function getOAuthToken() {
  const form = new URLSearchParams({
    client_id: process.env.GBP_CLIENT_ID,
    client_secret: process.env.GBP_CLIENT_SECRET,
    refresh_token: process.env.GBP_REFRESH_TOKEN,
    grant_type: "refresh_token"
  });
  const response = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: form
  });
  if (!response.ok) throw new Error("Google OAuth unavailable");
  const json = await response.json();
  if (!json.access_token) throw new Error("OAuth returned no token");
  return json.access_token;
}
async function getAllReviews(token) {
  const account = String(process.env.GBP_ACCOUNT_ID).replace(/\D/g, "");
  const location = String(process.env.GBP_LOCATION_ID).replace(/\D/g, "");
  if (!account || !location) throw new Error("invalid GBP IDs");
  const base = `https://mybusiness.googleapis.com/v4/accounts/${account}/locations/${location}/reviews`;
  let pageToken = null, reviews = [], pages = 0;
  do {
    const url = new URL(base);
    url.searchParams.set("pageSize", "50");
    url.searchParams.set("orderBy", "updateTime desc");
    if (pageToken) url.searchParams.set("pageToken", pageToken);
    const response = await fetch(url, {
      headers: { Authorization: `Bearer ${token}` }, signal: AbortSignal.timeout(10000)
    });
    if (!response.ok) throw new Error(`Google Business Profile status ${response.status}`);
    const data = await response.json();
    if (Array.isArray(data.reviews)) reviews.push(...data.reviews);
    pageToken = data.nextPageToken || null;
    pages++;
    // Ceiling avoids excessive requests. If reached, avoid claiming an exhaustive newest-by-date result.
    if (pages >= 100 && pageToken) throw new Error("Too many pages for reliable newest-review guarantee");
  } while (pageToken);
  return reviews;
}
module.exports = async function handler(req, res) {
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  res.setHeader("Cache-Control", "public, s-maxage=1800, stale-while-revalidate=3600");
  if (req.method !== "GET") return fail(res, 405, "method_not_allowed");
  if (!REQUIRED.every(k => process.env[k])) return res.status(200).json(snapshot);
  if (cache.payload && cache.expires > Date.now()) return res.status(200).json(cache.payload);
  try {
    const token = await getOAuthToken();
    const all = await getAllReviews(token);
    const fiveStar = all.filter(r => r.starRating === "FIVE")
      .sort((a,b) => new Date(b.createTime || b.updateTime) - new Date(a.createTime || a.updateTime))
      .map(r => ({
        author: r.reviewer?.isAnonymous ? "Cliente do Google" : (r.reviewer?.displayName || "Cliente do Google"),
        text: String(r.comment || "").trim(),
        date: r.createTime || r.updateTime || null,
        rating: 5
      }));
    const url = process.env.GBP_MAPS_URL || "https://maps.app.goo.gl/KH8BSwpBCeTkNb8z7";
    const payload = { status: fiveStar.length ? "ok" : "no_matching_reviews", reviews: fiveStar, googleMapsUrl: url };
    cache = { expires: Date.now()+1800000, payload };
    return res.status(200).json(payload);
  } catch (e) {
    // Do not disclose Google OAuth errors or any credentials to a visitor.
    console.error("Google reviews integration:", e.message);
    return res.status(200).json(snapshot);
  }
};
